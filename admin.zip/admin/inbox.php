<?php 
include '../partials/head.php';
include '../partials/admin_header.php';

?>

    <div class="single_post">
		<div class="container">
			<div class="row">
				<div class="col-lg-10">
                        <div class="box">
                            <div class="box-header">
                                <h3 class="box-title">Online Bookings</h3>
                            </div>
                            <!-- /.box-header -->
                                <div class="box-body">
                                    <table id="example2" class="table table-bordered table-hover">
                                            <thead>
                                                <tr>
                                                    <th>Name</th>
                                                    <th>Phone</th>
                                                    <th>Email</th
                                                </tr>
                                            </thead>
                                        <tbody>
                	                    <?php
        				                    include '../partials/connection.php';
        				                    //Collecting all clients' details from the clients' table
        				                    $sql = "SELECT * FROM bookings ORDER BY id DESC";
        				                    $client = mysqli_query($conn, $sql) or die(mysqli_connect_error());
        				
                                            while ($row = mysqli_fetch_array($client, MYSQLI_ASSOC))
                                           
                                             {
        					                //fetch based on id
                                        ?>
                                        
                                        <tr>
                                        <td><a href="car.php<?php echo '?id='.$row['id'];?>"> <?php echo $row['name'];?> </a> </td>
                                        <td><a href="car.php<?php echo '?id='.$row['id'];?>"> <?php echo $row['phone'];?> </a> </td>
                                        <td><a href="car.php<?php echo '?id='.$row['id'];?>"> <?php echo $row['email'];?> </a> </td>
                                        
                                        </tr>
                                            </a>
                                        <?php }?>
                                        </tbody>
                                    </table>
                                </div>
                                <!-- /.box-body -->
                        </div>
				</div>
			</div>
		</div>
	</div>
    
<?php include '../partials/footer.php'; ?>
	
<script src="../js/jquery-3.3.1.min.js"></script>
<script src="../styles/bootstrap4/popper.js"></script>
<script src="../styles/bootstrap4/bootstrap.min.js"></script>
<script src="../plugins/greensock/TweenMax.min.js"></script>
<script src="../plugins/greensock/TimelineMax.min.js"></script>
<script src="../plugins/scrollmagic/ScrollMagic.min.js"></script>
<script src="../plugins/greensock/animation.gsap.min.js"></script>
<script src="../plugins/greensock/ScrollToPlugin.min.js"></script>
<script src="../plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
<script src="../plugins/slick-1.8.0/slick.js"></script>
<script src="../plugins/easing/easing.js"></script>
<script src="../js/custom.js"></script>
</body>

</html>