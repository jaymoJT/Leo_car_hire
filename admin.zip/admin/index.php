<?php 
include '../partials/head.php';
include '../partials/admin_header.php';



?>


    <div class="single_post">
		<div class="container">
			<div class="row">
				<div class="col-lg-8 offset-2">
					<div class="single_post_title"><h2>Add new car to the fleet</h2> </div>
					<div class="single_post_text">
                        <div class="single_post_quote text-center" style="text-align: left;">
                        <?php 
                         if (isset($_POST['add'])) {
                             include_once '../partials/connection.php';
                             if (getimagesize($_FILES['pic']['tmp_name'])==TRUE)
                                    {
                                      $pic = addslashes(($_FILES['pic']['tmp_name']));
                                      $pic=file_get_contents($pic);
                                      $pic=base64_encode($pic);
                                    }


                                    $make = mysqli_real_escape_string($conn, $_POST['make']);
                                    $model = mysqli_real_escape_string($conn, $_POST['model']);
                                    $brand = mysqli_real_escape_string($conn, $_POST['brand']);
                                    $class = mysqli_real_escape_string($conn, $_POST['class']);
                                    $message = '';

                                    //checking for errors
                                    //start by checking for empty fields
                                    if (empty($make) || empty($model) || empty($brand) || empty($pic) || empty($class) ) {
                                        $message = 'You have submitted an empty field!';
                                    } 
                                    else {
                                        $fleet = "INSERT INTO fleet (make, model, brand, image, class)
                                        VALUES ('$make','$model','$brand','$pic','$class') ";
                                    }
                                    if (mysqli_query($conn, $fleet)) {
                                        $message = 'The car has been added successfully';
                                    } 
                                    else {
                                        $message = 'System error; Data not sent , Kindly contact the developer  to sort!';
                                    }

                         }
                        ?>
                            <form style="text-align:left;" method="POST" enctype="multipart/form-data">
                                <?php if(!empty($message)): ?>
                                    <div class="alert-danger" style="border-radius: 5px; text-align:center;">
                                      <?php echo $message; ?> 
                                    </div>
                                <?php endif ;?>
                                <div class="col-md-7">
                                    <div class="form-group">
                                        <label>Car Make</label>
                                        <input type="text" class="form-control" name="make" />
                                    </div>
                                    <div class="form-group">
                                        <label>Car Model</label>
                                        <input type="text" class="form-control" name="model" />
                                    </div>
                                </div>
                                <div class="col-md-7">
                                    <div class="form-group">
                                        <label>Brand</label>
                                        <input type="text" class="form-control" name="brand" />
                                    </div>
                                    <div class="form-group">
                                        <label>Image</label>
                                        <input type="file" class="form-control btn-success" name="pic" />
                                    </div>
                                    <div class="form-group"> 
                                    <label>Class</label>                    
                                    <select id="basic" class="selectpicker2 show-tick form-control" name="class">
                                        <option> -Select- </option>
                                        <option>A</option>
                                        <option>B</option>
                                        <option>C</option>
                                        <option>D</option>
                                        <option>E</option>
                                        <option>F</option>                                        
                                    </select>
                                </div>
                                </div>  
                               <button class="btn btn-success" type="submit"  value="send" name="add" style="color:#fff;">Add</button>                             
                            </form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>


<?php include '../partials/footer.php'; ?>
	
<script src="../js/jquery-3.3.1.min.js"></script>
<script src="../styles/bootstrap4/popper.js"></script>
<script src="../styles/bootstrap4/bootstrap.min.js"></script>
<script src="../plugins/greensock/TweenMax.min.js"></script>
<script src="../plugins/greensock/TimelineMax.min.js"></script>
<script src="../plugins/scrollmagic/ScrollMagic.min.js"></script>
<script src="../plugins/greensock/animation.gsap.min.js"></script>
<script src="../plugins/greensock/ScrollToPlugin.min.js"></script>
<script src="../plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
<script src="../plugins/slick-1.8.0/slick.js"></script>
<script src="../plugins/easing/easing.js"></script>
<script src="../js/custom.js"></script>
</body>

</html>