
<?php 
if (isset($_POST['logout'])) {
	 session_unset();
   session_destroy();
}

?>

<header class="header">
    <form method="POST">
		<!-- Top Bar -->
		<div class="top_bar" >
			<div class="container">
				<div class="row">
					<div class="col d-flex flex-row">
						<div class="top_bar_contact_item"><div class="top_bar_icon"><img src="images/phone.png" alt=""></div>+254 799 615 530</div>
						<div class="top_bar_contact_item"><div class="top_bar_icon"><img src="images/mail.png" alt=""></div><a href="mailto:info@leoblaze.africa">info@leoblaze.africa</a></div>
						<div class="top_bar_content ml-auto">
							<div class="top_bar_user">
							<?php if (!isset($_SESSION['s_email'])) {?>
		                        <div class="user_icon"><img src="images/user.svg" alt=""></div>
								<div><a href="register.php">Register</a></div> |
								<div><a href="login.php">Sign in</a></div>
	                        <?php }  else {
	                            include 'connection.php';
	                                $user = $_SESSION['s_email'];
                                    $get_user = "SELECT * FROM  users WHERE email='$user' ";
                                    $right_user = mysqli_query($conn,$get_user) or die (mysqli_connect_error());
                                    while ($row = mysqli_fetch_array($right_user, MYSQLI_ASSOC)) {?> 
                                     <!-- To display the user's name -->
                                        <div>
                                        	<a href="#"><?php echo $row['f_name']; ?> <?php echo $row['l_name']; ?></a>
                                        </div> |
								        <div>
								        	<button type="submit" name="logout" style="background-color: transparent;color: #fff;">Logout</button>
								        </div>
	            	                    
	                                <?php }?>
	                        <?php }?>	
								                                 
							</div>
						</div>
					</div>
				</div>
			</div>		
		</div>
    </form>
		<div class="container pull-right" style="text-align:center;">
		  <ul>
			 
				    <a href="index.php" style="color:#000; font-size:150%; ">Home</a>|
				 
				
				    <a href="#" style="color:#000; font-size:150%;">Add Fleet</a>|
				 
				
				    <a href="inbox.php" style="color:#000; font-size:150%;">Inbox</a>|
				 
				
				    <a href="#" style="color:#000; font-size:150%;">Send SMS</a>|
				 
			
			</ul>
		</div>

	</header>