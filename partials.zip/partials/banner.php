    <div class="banner" style="">
		<div class="banner_background img-responsive" style="max-height:100%; background-image:url(images/real.jpg)">
		<marquee style="background-color:#0c0c0cc2; color:yellow; height:10%;" >
		<div style="margin-top:1%;margin-bottom:1%;">
		We are a renown company in Kenya offering quality and affordable Car Hire, 
		Hotels & Villas and Tour Safaris across the country. 
		 we value you as a customer and at all times  provide the best service to you.
		</div>	 
		</marquee>
		</div>		
		<div class="container fill_height">
			<div class="row fill_height">				
				<div class="col-lg-5 offset-lg-4 fill_height">
					<div class="banner_content">
						<h1 class="banner_text" style="color:#fff;">Travel in style</h1>
						<div class="button banner_button"><a href="fleet.php">Rent Car</a></div>
					</div>
				</div>
			</div>
		</div>
	</div>