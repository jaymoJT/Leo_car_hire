<?php 
if (isset($_POST['logout'])) {
	 session_unset();
   session_destroy();
}

?>


<?php include 'partials/top.php'; ?>
<header class="header">
		<div class="header_main">
			<div class="container">
				<div class="row">

					<!-- Logo -->
					<div class="col-lg-2 col-sm-3 col-3 order-1">
						<div class="logo_container">
							<div class="logo"><a href="index.php">Eden</a></div>
						</div>
					</div>

					<!-- Search -->
					<div class="col-lg-6 col-12 order-lg-2 order-3 text-lg-left text-right">
						<div class="header_search">
							<div class="header_search_content">
								<div class="header_search_form_container">
									<form action="#" class="header_search_form clearfix">
										<input type="search" required="required" class="header_search_input " placeholder="Search for albums..." style="color:#000;">
										<div class="custom_dropdown">
											<div class="custom_dropdown_list">
												<span class="custom_dropdown_placeholder clc" style="color:#000;">All Categories</span>
												
												<ul class="custom_list clc">
													<li><a class="clc" href="#" style="color:#000;">All Categories</a></li>
													<li><a class="clc" href="#" style="color:#000;">Audios</a></li>
													<li><a class="clc" href="#" style="color:#000;">Videos</a></li>
												</ul>
											</div>
										</div>
										<button type="submit" class="header_search_button trans_300" value="Submit"><img src="images/search.png" alt=""></button>
									</form>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-4 col-9 order-lg-3 order-2 text-lg-left text-right">
						<div class="wishlist_cart d-flex flex-row align-items-center justify-content-end">
							<div class="wishlist d-flex flex-row align-items-center justify-content-end">				
							    <a href="fleet.php">
							    <div class="wishlist_content" style="text-align:center;">
								     <h3><i class="fas fa-car"></i></h3>  
									<div class="wishlist_text">Rent Car</div>
									<div class="wishlist_count"></div>
								</div>
								</a>
							</div>
							<!-- Cart -->
							<div class="cart">
								<div class="cart_container d-flex flex-row align-items-center justify-content-end">									
								    <a href="#">
								    <div class="cart_content" style="text-align:center;">										
									    <h3><i class="fas fa-bed"></i></h3> 
										<div class="cart_text">Accomodation</div>
										<div class="cart_price"></div>
									</div>
									</a>
								</div>
							</div>
						</div>
					</div>		
				</div>
			</div>
		</div>		
		<!-- Main Navigation -->

		<nav class="main_nav" style="margin-bottom:-20px; background-color:#fff; color:#000; ">
			<div class="container">
				<div class="row">
					<div class="col">						
						<div class="main_nav_content d-flex flex-row">
							<div class="cat_menu_container">
								<div class="cat_menu_title d-flex flex-row align-items-center justify-content-start">
									<div class="cat_burger"><span></span><span></span><span></span></div>
									<div class="cat_menu_text">More</div>
								</div>
								<ul class="cat_menu">
									<li><a href="#" style="color:#000;">Terms & Conditions<i class="fas fa-chevron-right ml-auto"></i></a></li>
									<li><a href="#" style="color:#000;">Our Pricing<i class="fas fa-chevron-right"></i></a></li>
								</ul>
							</div>
							<div class="main_nav_menu ml-auto">
								<ul class="standard_dropdown main_nav_dropdown clc">
									<li>
										<a class="clc" href="index.php">										
											<b>Home</b> 											  											
										</a>
									</li>
									<li>
										<a href="about.php">
										    <b>About us</b>   											
										</a>
									</li>
									<li class="hassubs">
										<a href="#">
										      <b>Our Fleet</b> 
											<i class="fas fa-chevron-down"></i>
										</a>
										<ul style="background-color:#000; color:#fff; width:130px;">
											<li>
												<a href="a.php?cars=all/As/" style="color:#fff;">
												      Class A													
												</a>
											</li>
											<li>
												<a href="b.php?cars/all/Bs/" style="color:#fff;">
												      Class B 													
												</a>
											</li>
											<li>
												<a href="c.php?cars/all/Cs/" style="color:#fff;">
												      Class C 													
												</a>
											</li>
											<li>
												<a href="d.php?cars/all/Ds/" style="color:#fff;">
												      Class D 													
												</a>
											</li>
											<li>
												<a href="e.php?cars/all/Es/" style="color:#fff;">
												      Class E 													
												</a>
											</li>
											<li>
												<a href="f.php?cars/all/Fs/" style="color:#fff;">
												      Class F													
												</a>
											</li>
										</ul>
									</li>									
									<li>
										<a href="contact.php">
										    <b>Contact us</b>   											
										</a>
									</li>
								</ul>
							</div>
							<div class="menu_trigger_container ml-auto">
								<div class="menu_trigger d-flex flex-row align-items-center justify-content-end">
									<div class="menu_burger">
										<div class="menu_trigger_text">menu</div>
										<div class="cat_burger menu_burger_inner"><span></span><span></span><span></span></div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</nav>






		
		<!-- Menu -->

		<div class="page_menu">
			<div class="container">
				<div class="row">
					<div class="col">						
						<div class="page_menu_content">
							<div class="page_menu_search">
								<form action="#">
									<input type="search" required="required" class="page_menu_search_input" placeholder="Search for products...">
								</form>
							</div>
							<ul class="page_menu_nav">
								<li class="page_menu_item">
									<a href="index.php">Home<i class="fa fa-angle-down"></i></a>
								</li>
								<li class="page_menu_item">
									<a href="#">About us<i class="fa fa-angle-down"></i></a>
								</li>
								<li class="page_menu_item has-children">
									<a href="#">Need help?<i class="fa fa-angle-down"></i></a>
									<ul class="page_menu_selection">
										<li><a href="shop.php">How to buy</a></li>
										<li><a href="payments.php">Payment Policy</a></li>
										<li><a href="#">Download Policy<i class="fa fa-angle-down"></i></a></li>
									</ul>
								</li>
								<li class="page_menu_item"><a href="#">Artists<i class="fa fa-angle-down"></i></a></li>
								<li class="page_menu_item"><a href="#">Latest Albums<i class="fa fa-angle-down"></i></a></li>
								<li class="page_menu_item"><a href="shop.php">Shop<i class="fa fa-angle-down"></i></a></li>
							</ul>
							
							<div class="menu_contact">
								<div class="menu_contact_item"><div class="menu_contact_icon"><img src="images/phone_white.png" alt=""></div>+254 799 615 530</div>
								<div class="menu_contact_item"><div class="menu_contact_icon"><img src="images/mail_white.png" alt=""></div><a href="mailto:fastsales@gmail.com">support@barakasong.co.ke</a></div>
								<div>
									<form method="POST">
										<?php if (!isset($_SESSION['s_email'])) {?>
		                                    <div class="user_icon"><img src="images/user.svg" alt=""></div>
								            <a href="register.php">Register</a> |
								            <a href="login.php">Sign in</a>
	                                        <?php }  else {
	                                                include 'connection.php';
	                                                $user = $_SESSION['s_email'];
                                                    $get_user = "SELECT * FROM  users WHERE email='$user' ";
                                                    $right_user = mysqli_query($conn,$get_user) or die (mysqli_connect_error());
                                                        while ($row = mysqli_fetch_array($right_user, MYSQLI_ASSOC)) {?> 
                                                          <!-- To display the user's name -->
                                                            
                                        	                    <a href="#">
                                        	              	        <?php echo $row['f_name']; ?> <?php echo $row['l_name']; ?>
                                        	              	    </a>
                                                                |
								        	                    <button type="submit" name="logout" style="background-color: transparent;color: #fff;">Logout</button>
								                            
	                                                    <?php }?>
	                                                <?php }?>	
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

	</header>