<div class="banner_2" style="max-height:60%;" >
		<div class="banner_2_background" style="max-height:60%; background-image:url(images/eden2.jpg)"></div>
		<div class="banner_2_container">
			<div class="banner_2_dots"></div>
			<!-- Banner 2 Slider -->
			<div class="owl-carousel owl-theme banner_2_slider">
				<!-- Banner 2 Slider Item -->
				<div class="owl-item">
					<div class="banner_2_item">
						<div class="container fill_height">
							<div class="row fill_height">
							
								<div class="col-lg-4 col-md-6 fill_height">
									<div class="banner_2_content">
										<div class="text_content">
											   <h3>Space</h3>
										       
										</div>
										
										<div class="button banner_2_button"><a href="fleet.php?/fleet/cars/all/">Fleet</a></div>
									</div>
									
								</div>
								
							</div>
						</div>			
					</div>
				</div>

				<!-- Banner 2 Slider Item -->
				<div class="owl-item">
					<div class="banner_2_item">
						<div class="container fill_height">
							<div class="row fill_height">
								<div class="col-lg-8 col-md-6 fill_height">
									<div class="banner_2_image_container">
										<div class="banner_2_image"><img src="images/2.png" alt=""></div>
									</div>
								</div>
								<div class="col-lg-4 col-md-6 ">
									<div class="banner_2_content">
										<div class="text_content" >
											<h3>Space</h3>
										    <div class="banner_2_title">Adequate fleet</div>
											<div class="banner_2_text">We provide our clients a wide range of products and models to suit their needs.</div>
											<div class="rating_r rating_r_4 banner_2_rating"><i></i><i></i><i></i><i></i><i></i></div>
											<h3>space </h3>
										</div>
										<div class="button banner_2_button"><a href="fleet.php?/fleet/cars/all/">Fleet</a></div>
									</div>
									
								</div>
								
							</div>
						</div>			
					</div>
				</div>

				<!-- Banner 2 Slider Item -->
				<div class="owl-item">
					<div class="banner_2_item">
						<div class="container fill_height">
							<div class="row fill_height">
								<div class="col-lg-8 col-md-6 fill_height">
									<div class="banner_2_image_container">
										<div class="banner_2_image"><img src="images/3.png" alt=""></div>
									</div>
								</div>
								<div class="col-lg-4 col-md-6 fill_height">
									<div class="banner_2_content">
									    <div class="text_content" >
											<h3>space</h3>
										    <div class="banner_2_title">Client Satisfaction</div>
										    <div class="banner_2_text">We work constantly towards meeting every clients' needs throught a well dedicated staff.</div>
											<div class="rating_r rating_r_4 banner_2_rating"><i></i><i></i><i></i><i></i><i></i></div>
											<h3>space</h3>
                                        </div>
										<div class="button banner_2_button"><a href="fleet.php?/fleet/cars/all/">Fleet</a></div>
									</div>
									
								</div>
								
							</div>
						</div>			
					</div>
				</div>

			</div>
		</div>
	</div>
