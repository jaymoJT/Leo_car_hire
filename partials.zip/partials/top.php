<div class="top_bar">
			<div class="container">
				<div class="row">
					<div class="col d-flex flex-row">
						<div class="top_bar_contact_item"><div class="top_bar_icon"><i class="fas fa-phone"></i></div>020 2229893</div>
						<div class="top_bar_contact_item"><div class="top_bar_icon"><i class="fas fa-phone"></i></div>+254 722 410 172</div>
						<div class="top_bar_contact_item"><div class="top_bar_icon"><i class="far fa-envelope"></i></div><a href="mailto:info@edenrentacar.com">info@edenrentacar.com</a></div>
						<div class="top_bar_content ml-auto">
							<div class="top_bar_user">
							<a href="#"><i class="fab fa-facebook-f"></i></a>
							<a href="#"><i class="fab fa-twitter"></i></a>
							<a href="#"><i class="fab fa-youtube"></i></a>
							</div>
						</div>
					</div>
				</div>
			</div>		
		</div>